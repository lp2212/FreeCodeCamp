import numpy as np

def calculate(list):
    calculations = {
  'mean': [],
  'variance': [],
  'standard deviation': [],
  'max': [],
  'min': [],
  'sum': []
}
    if len(list) < 9:
      raise ValueError("List must contain nine numbers.")
    else:
      arr = np.array(list).reshape(3,3)
    
    b = np.zeros_like(arr, dtype='float')
    
    b[0] = np.mean(arr, axis=0)
    b[1] = np.mean(arr, axis=1)
    b[2] = np.mean(arr)
    for i in b[:2]:
        calculations['mean'].append(i.tolist())
    calculations['mean'].append(b[2][0])
    
    
    b[0] = np.var(arr, axis=0)
    b[1] = np.var(arr, axis=1)
    b[2] = np.var(arr)
    for i in b[:2]:
        calculations['variance'].append(i.tolist())
    calculations['variance'].append(b[2][0])
    
    b[0] = np.std(arr, axis=0)
    b[1] = np.std(arr, axis=1)
    b[2] = np.std(arr)
    for i in b[:2]:
        calculations['standard deviation'].append(i.tolist())
    calculations['standard deviation'].append(b[2][0])
    
    b[0] = np.max(arr, axis=0)
    b[1] = np.max(arr, axis=1)
    b[2] = np.max(arr)
    for i in b[:2]:
        calculations['max'].append(i.tolist())
    calculations['max'].append(b[2][0])
    
    b[0] = np.min(arr, axis=0)
    b[1] = np.min(arr, axis=1)
    b[2] = np.min(arr)
    for i in b[:2]:
        calculations['min'].append(i.tolist())
    calculations['min'].append(b[2][0])
    
    b[0] = np.sum(arr, axis=0)
    b[1] = np.sum(arr, axis=1)
    b[2] = np.sum(arr)
    for i in b[:2]:
        calculations['sum'].append(i.tolist())
    calculations['sum'].append(b[2][0])
    
    return calculations
