import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from scipy.stats import linregress

def draw_plot():
    # Read data from file
    df = pd.read_csv("epa-sea-level.csv")

    # Create scatter plot
    plt.scatter(x=df["Year"], y=df["CSIRO Adjusted Sea Level"])

    # Create first line of best fit
    rs1 = linregress(x=df["Year"], y=df["CSIRO Adjusted Sea Level"])
    X1 = np.arange(1880,2051,1)
    Y1 = X1*rs1.slope+rs1.intercept
    # Create second line of best fit
    rs2 = linregress(x=df[df["Year"]>=2000]["Year"], y=df[df["Year"]>=2000]["CSIRO Adjusted Sea Level"])
    X2 = np.arange(2000,2051,1)
    Y2 = X2*rs2.slope+rs2.intercept
    # Add labels and title
    plt.ylabel("Sea Level (inches)")
    plt.xlabel("Year")
    plt.title("Rise in Sea Level")
    plt.plot(X1, Y1)
    plt.plot(X2, Y2)
    # Save plot and return data for testing (DO NOT MODIFY)
    plt.savefig('sea_level_plot.png')
    return plt.gca()